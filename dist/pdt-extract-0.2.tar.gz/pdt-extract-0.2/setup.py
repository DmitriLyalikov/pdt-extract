from setuptools import setup, find_packages

setup(
    name='pdt-extract',
    version='0.2',
    packages=find_packages(),
    py_modules=['pdt_canny'],
    install_requires=[
        'imageio',
        'scipy',
        'numpy',
        'matplotlib',
        'circle_fit'
    ],
    entry_points={
        'console_scripts': [
            'pdt-extract = pdt_canny:main'
        ]
    },

    description="Perform edge profile and characteristic feature extraction from images of pendant drops",
    author_email='Dlyalikov01@manhattan.edu',
    author='Dmitri Lyalikov'
)